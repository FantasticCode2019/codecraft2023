#include <iostream>
#include <vector>
#include <fstream>
#include <cmath>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <unistd.h>
#include "DWA.h"

//#define Pi 3.14159
//#define debug
using namespace std;



constexpr double dt = 0.02;
constexpr double v_min = -2.0;
constexpr double v_max = 6.0;
constexpr double w_min = -Pi;
constexpr double w_max = Pi;
constexpr double predict_time = 0.28;
double a_vmax = max(g_va[0], g_va[1]);
double a_wmax = max(g_wa[0], g_wa[1]);
constexpr double v_sample = 0.10;
constexpr double w_sample = 2.0 * Pi / 180;
constexpr double a = 1.2;
constexpr double b = 1.0;
constexpr double c = 0.2;  
constexpr double radius = 0.4;
constexpr double judge_distance = 1.6;



struct ProductValueStruct
{
    int buyValue;
    int sellValue;
    ProductValueStruct(int b, int s) {
        buyValue = b;
        sellValue = s;
    }
    int GetProfit() {
        return sellValue - buyValue;
    }
};

class ProductValue
{
public:
    static vector<ProductValueStruct> ProductList;
};
vector<ProductValueStruct> ProductValue::ProductList = {
    ProductValueStruct(0, 0),
    ProductValueStruct(3000, 6000),
    ProductValueStruct(4400, 7600),
    ProductValueStruct(5800, 9200),
    ProductValueStruct(15400, 22500),
    ProductValueStruct(17200, 25000),
    ProductValueStruct(19200, 27500),
    ProductValueStruct(76000, 105000)
};


class Map
{
public:
	static void InsertToMap(int x, int y, char c) {
		if (x < 0 || y < 0 || x > 99 || y > 99) {
			return;
		}
		map[x][y] = c;
	}
public:
	static vector<vector<char>> map;
};

vector<vector<char>> Map::map 
	= vector<vector<char>>(110, vector<char>(110, ' '));



class Robot
{
public:
	Robot(int StageId, int CarriedItemType, double TimeValueCoef, double CollisionValueCoef,
    double Palstance, DoubleXY LinearVeclocity, double Direction, DoubleXY pos) : StageId(StageId), 
    CarriedItemType(CarriedItemType), TimeValueCoef(TimeValueCoef), CollisionValueCoef(CollisionValueCoef), 
    Palstance(Palstance), LinearVeclocity(LinearVeclocity), Direction(Direction), pos(pos) {}

    void UpdateRobotStatus(int StageId, int CarriedItemType, double TimeValueCoef, double CollisionValueCoef,
    double Palstance, DoubleXY LinearVeclocity, double Direction, DoubleXY pos) {
        this->StageId = StageId;
        this->CarriedItemType = CarriedItemType;
        this->TimeValueCoef = TimeValueCoef;
        this->CollisionValueCoef = CollisionValueCoef;
        this->Palstance = Palstance;
        this->LinearVeclocity = LinearVeclocity;
        this->Direction = Direction;
        this->pos = pos;
    }
public:
	int StageId;  // -1. [0, n - 1]当前所处工作台id
	int CarriedItemType;  // 0-7携带物品类型
	double TimeValueCoef;  // [0.8, 1]时间系数
	double CollisionValueCoef; // [0.8, 1]碰撞系数
	double Palstance;  // 角速度
	DoubleXY LinearVeclocity;  // 线速度
	double Direction;  // 朝向
	DoubleXY pos;  // 位置
    int TargetStageId = -1;  // 目标
};

class Stage
{
public:
	Stage(int id, int type, DoubleXY pos, int RemainProdTime, 
		int RawGridStatus, int ProductGridStatus) : id(id), type(type), pos(pos), 
        RemainProdTime(RemainProdTime), RawGridStatus(RawGridStatus), ProductGridStatus(ProductGridStatus) {
            IsSellTarget = vector<int>(10, 0);
        }

    void UpdateStageStatus(int id, int type, DoubleXY pos, int RemainProdTime, 
		int RawGridStatus, int ProductGridStatus) {
            this->id = id;
            this->type = type;
            this->pos = pos;
            this->RemainProdTime = RemainProdTime;
            this->RawGridStatus = RawGridStatus;
            this->ProductGridStatus = ProductGridStatus;
        }
public:
    int id;
	int type;  // 1-9
	DoubleXY pos;  // 坐标
	int RemainProdTime;  // -1, 0, >=0
	int RawGridStatus;
	int ProductGridStatus; // 0, 1
    vector<int> IsSellTarget;  // 是否被当成卖东西的目标
    int IsBuyTarget = 0;  // 是否被当成买东西的目标
};

class ProductPriorityQueueCmpFunc
{
public:
    bool operator() (const Stage& s1, const Stage& s2) {
        if (s1.ProductGridStatus == s2.ProductGridStatus && s1.ProductGridStatus == 0) {
            return s1.RemainProdTime > s2.RemainProdTime;
        } else if (s1.ProductGridStatus == s2.ProductGridStatus && s1.ProductGridStatus == 1) {
            return ProductValue::ProductList[s1.type].GetProfit() < ProductValue::ProductList[s2.type].GetProfit();
        }
        return s1.ProductGridStatus < s1.ProductGridStatus;
    }
};


class AvoidCollision
{
public:
    AvoidCollision(const AvoidCollision& t) = delete;
    AvoidCollision& operator=(const AvoidCollision& t) = delete;
    static DWA* getDWA() {
        return m_dwa;
    }
private:
    static DWA* m_dwa;
};
DWA* AvoidCollision::m_dwa = new DWA(dt, v_min, v_max, w_min, w_max, predict_time, a_vmax,
a_wmax, v_sample, w_sample, a, b, c, radius, judge_distance);


class Project
{
public:
    Project();
	void run();
	bool readMapUntilOK();
	bool readFrameUntilOK();
    bool InsertToMProductToStage(int RawGridStatus, int ProductType, int StageId);
    void MoveRobot();
    double GetV0(double x, double y);
    double GetDistance(DoubleXY p1, DoubleXY p2);
    double GetTargetDir(DoubleXY CurPos, DoubleXY TargetPos);
    bool AdjustDirectionAndSpeed();
    int GetTargetStageToSell(int CarriedItem, int RobotId);
    bool RobotBuyItem(int RobotId, int StageId);
    int AssignmentTargetStage(int RobotId);
    void AdjustRobotTarget(int RobotId);
    bool ToIdle(int RobotId);
    bool ToBusy(int RobotId);
private:
	int balance = 0;
	int CurFrameNum = 1;
	int StageNum = 0;
	std::vector<Stage> StageList;
	std::vector<Robot> RobotList;
    priority_queue<Stage, vector<Stage>, ProductPriorityQueueCmpFunc> ProductPriorityQueue_123;
    priority_queue<Stage, vector<Stage>, ProductPriorityQueueCmpFunc> ProductPriorityQueue_4567;
    unordered_map<int, unordered_set<int>> m_ProductToStage;  // 各类商品与需要且有空格的工作台
    int IdleRobot = (1 << 5) - 1;  // 11111 
    

};

Project::Project() {
    RobotList = vector<Robot>(4, Robot(0, 0, 1.0, 1.0, 1.0, DoubleXY(1.0, 1.0), 1.0, DoubleXY(1.0, 1.0)));
    StageList = vector<Stage>(51, Stage(0, 0, DoubleXY(1.0, 1.0), 0, 0, 0));
}

bool Project::AdjustDirectionAndSpeed()
{
    vector<DoubleXY> obstacle;
    for (int i = 0; i < 4; ++i) {
        RobotPose state(RobotList[i].pos.x, RobotList[i].pos.y, RobotList[i].Direction, GetV0(RobotList[i].LinearVeclocity.x, RobotList[i].LinearVeclocity.y), RobotList[i].Palstance); //[x(m), y(m), yaw(rad), v(m/s), omega(rad/s)]
        a_vmax = RobotList[i].CarriedItemType == 0 ? g_va[0] : g_va[1];
        a_wmax = RobotList[i].CarriedItemType == 0 ? g_wa[0] : g_wa[1];
        if(i&1 == 0){
            a_vmax = -a_vmax;
            a_wmax = -a_wmax;
        }
        pair<vector<double>, vector<RobotPose>>&& res = AvoidCollision::getDWA()->DwaControl(state, StageList[RobotList[i].TargetStageId].pos, obstacle);
        printf("rotate %d %f\n", i, res.first[1]);
        printf("forward %d %f\n", i, res.first[0]);
        int num = 14;  //取多少帧的数据作为障碍物
        for (int j = 0; j < res.second.size() && num > 0; ++j) {
            obstacle.emplace_back(DoubleXY(res.second[j].x, res.second[j].y));
            --num;
        }
    }
}



double Project::GetTargetDir(DoubleXY CurPos, DoubleXY TargetPos)
{
    double ty = TargetPos.y - CurPos.y, tx = TargetPos.x - CurPos.x;
    double TargetDir = 0.0;
    if (tx == 0.0) {
        TargetDir = ty > 0.0 ? Pi / 2 : -Pi / 2;
    } else if (ty == 0.0) {
        TargetDir = tx > 0.0 ? 0.0 : -Pi;
    } else {
        TargetDir = atan(ty / tx);
        if (ty > 0 && tx < 0) {
            TargetDir += Pi;
        } else if (ty < 0 && tx < 0) {
            TargetDir -= Pi;
        }
    }
    if (TargetDir < 0) {
        TargetDir += 2 * Pi;
    }
    return TargetDir;
}

int Project::AssignmentTargetStage(int RobotId)
{
    vector<Stage> temp;
    int resStageId = -1;
    double dis = 100.0;
    int type = 0;
    if (!ProductPriorityQueue_4567.empty() && ProductPriorityQueue_4567.top().ProductGridStatus == 1) {
        while (!ProductPriorityQueue_4567.empty() && ProductPriorityQueue_4567.top().ProductGridStatus == 1) {
            Stage t = ProductPriorityQueue_4567.top();
            ProductPriorityQueue_4567.pop();
            double t_dis = GetDistance(RobotList[RobotId].pos, t.pos);
            if (t_dis < dis) {
                dis = t_dis;
                resStageId = t.id;
            }
            temp.push_back(t);
            type = 1;
        }
    } else if (!ProductPriorityQueue_123.empty()) {
        if (ProductPriorityQueue_123.top().ProductGridStatus == 1) {
            while (!ProductPriorityQueue_123.empty() && ProductPriorityQueue_123.top().ProductGridStatus == 1) {
                Stage t = ProductPriorityQueue_123.top();
                ProductPriorityQueue_123.pop();
                double t_dis = GetDistance(RobotList[RobotId].pos, t.pos);
                if (t_dis < dis) {
                    dis = t_dis;
                    resStageId = t.id;
                }
                temp.push_back(t);
                type = 2;
            }
        } else {
            while (!ProductPriorityQueue_123.empty()) {
                Stage t = ProductPriorityQueue_123.top();
                ProductPriorityQueue_123.pop();
                double t_dis = GetDistance(RobotList[RobotId].pos, t.pos);
                if (t_dis < dis) {
                    dis = t_dis;
                    resStageId = t.id;
                }
                temp.push_back(t);
                type = 2;
            }
        }
    }
    for (int i = 0; i < temp.size(); ++i) {
        if (temp[i].id != resStageId) {
            switch (type)
            {
                case 1:
                    ProductPriorityQueue_4567.push(temp[i]);
                    break;
                case 2:
                    ProductPriorityQueue_123.push(temp[i]);
                    break;
                default:
                    break;
            }
        }
    }
    return resStageId;
}





bool Project::RobotBuyItem(int RobotId, int StageId) 
{
    if (RobotId < 0 || RobotId > 3 || StageId < 0 || StageId >= StageNum) {
        return false;
    }
    Stage curStage = StageList[StageId];
    if (curStage.ProductGridStatus == 0) {
        return false;
    }
    if (balance < ProductValue::ProductList[curStage.type].buyValue) {
        return false;
    }
    int tempTargetStageId = GetTargetStageToSell(curStage.type, RobotId);
    if (tempTargetStageId == -1) {
        return false;
    }
    printf("buy %d\n", RobotId);
    RobotList[RobotId].CarriedItemType = curStage.type;
    RobotList[RobotId].TargetStageId = tempTargetStageId;
    StageList[tempTargetStageId].IsSellTarget[curStage.type] = 1;
    balance -= ProductValue::ProductList[curStage.type].buyValue;
    ToBusy(RobotId);
    return true;
}

bool Project::ToIdle(int RobotId) 
{
    if (RobotId < 0 || RobotId > 3) {
        return false;
    }
    IdleRobot |= (1 << RobotId);
    return true;
}

bool Project::ToBusy(int RobotId)
{
    if (RobotId < 0 || RobotId > 3) {
        return false;
    }
    IdleRobot &= ~(1 << RobotId);
    return true;
}


void Project::run()
{
    // 读取地图数据
    readMapUntilOK();
    puts("OK");
    fflush(stdout);

    // 读取每一帧数据
    int frameID;
    while (scanf("%d", &frameID) != EOF) {
        readFrameUntilOK();
        printf("%d\n", frameID);
        MoveRobot();
        ++CurFrameNum;
        printf("OK\n");
        fflush(stdout);
    }
}


int Project::GetTargetStageToSell(int CarriedItem, int RobotId) 
{
    DoubleXY CurRobotPos = RobotList[RobotId].pos;
    unordered_set<int> StageSet = m_ProductToStage[CarriedItem];
    if (StageSet.empty()) {
        return -1;
    }
    double id_9 = -1;
    double dis_9 = 3000.0;
    int res = -1;
    double dis = 3000.0;
    double RemainTime = (double)(9000.0 - CurFrameNum) * 20.0 / 1000.0;  // ###9000
    for (auto it = StageSet.begin(); it != StageSet.end(); ++it) {
        if (StageList[*it].IsSellTarget[CarriedItem] == 1) {
            continue;
        }
        if (StageList[*it].type == 9) {
            double t_dis_9 = GetDistance(StageList[*it].pos, CurRobotPos);
            if (t_dis_9 < dis_9 && t_dis_9 < RemainTime * 6.0 - 1.5) {
                id_9 = *it;
                dis_9 = t_dis_9; 
            }
            continue;
        }
        double tempDis = GetDistance(StageList[*it].pos, CurRobotPos);
        if (tempDis < dis && tempDis < RemainTime * 6.0 - 1.5) {
            res = *it;
            dis = tempDis;
        }
    }

    if (res != -1 && dis < dis_9 + 6.0) {  // ###
        m_ProductToStage[CarriedItem].erase(res);
    } else if (id_9 != -1) {
        res = id_9;
        m_ProductToStage[CarriedItem].erase(res);
    }
    return res;

}




double Project::GetV0(double x, double y) 
{
    return sqrt(x * x + y * y);
}

double Project::GetDistance(DoubleXY p1, DoubleXY p2) 
{
    return sqrt(abs(p1.x - p2.x) * abs(p1.x - p2.x) + abs(p1.y - p2.y) * abs(p1.y - p2.y));
}

void Project::AdjustRobotTarget(int RobotId)
{
    vector<Stage> temp;
    if (RobotList[RobotId].CarriedItemType > 0 || RobotList[RobotId].TargetStageId == -1) {
        return;
    }
    double curTargetDis = GetDistance(RobotList[RobotId].pos, StageList[RobotList[RobotId].TargetStageId].pos);
    Stage tempStage = StageList[RobotList[RobotId].TargetStageId];
    int resStageId = RobotList[RobotId].TargetStageId;
    while (!ProductPriorityQueue_4567.empty()) {
        Stage t = ProductPriorityQueue_4567.top();
        ProductPriorityQueue_4567.pop();
        if (t.ProductGridStatus == 1) {
            double t_dis = GetDistance(RobotList[RobotId].pos, t.pos);
            if (t_dis < curTargetDis && t.type > StageList[resStageId].type && !m_ProductToStage[t.type].empty()) {
                curTargetDis = t_dis;
                resStageId = t.id;
            }
        }
        temp.push_back(t);
    }
    // if (!ProductPriorityQueue_4567.empty() && ProductPriorityQueue_4567.top().ProductGridStatus == 1) {
    //     while (!ProductPriorityQueue_4567.empty() && ProductPriorityQueue_4567.top().ProductGridStatus == 1 && ProductPriorityQueue_4567.top().type > StageList[resStageId].type) {
    //         Stage t = ProductPriorityQueue_4567.top();
    //         ProductPriorityQueue_4567.pop();
    //         double t_dis = GetDistance(RobotList[RobotId].pos, t.pos);
    //         if (t_dis < curTargetDis) {
    //             curTargetDis = t_dis;
    //             resStageId = t.id;
    //         }
    //         temp.push_back(t);
    //     }   
    // }
    for (int i = 0; i < temp.size(); ++i) {
        if (temp[i].id != resStageId) {
            ProductPriorityQueue_4567.push(temp[i]);
        }
    }
    temp.clear();
    if (resStageId != tempStage.id) {
        StageList[RobotList[RobotId].TargetStageId].IsBuyTarget = 0;
        RobotList[RobotId].TargetStageId = resStageId;
        StageList[resStageId].IsBuyTarget = 1;
        if (tempStage.type <= 3) {
            ProductPriorityQueue_123.push(tempStage);
        } else {
            ProductPriorityQueue_4567.push(tempStage);
        }
    } else {
        while (!ProductPriorityQueue_123.empty()) {
            Stage t = ProductPriorityQueue_123.top();
            ProductPriorityQueue_123.pop();
            if (t.ProductGridStatus == 1) {
                double t_dis = GetDistance(RobotList[RobotId].pos, t.pos);
                if (t_dis < curTargetDis && t.type > StageList[resStageId].type && !m_ProductToStage[t.type].empty()) {
                    curTargetDis = t_dis;
                    resStageId = t.id;
                }
            }
            temp.push_back(t);
        }
        for (int i = 0; i < temp.size(); ++i) {
            if (temp[i].id != resStageId) {
                ProductPriorityQueue_123.push(temp[i]);
            }
        }
        if (resStageId != tempStage.id) {
            StageList[RobotList[RobotId].TargetStageId].IsBuyTarget = 0;
            RobotList[RobotId].TargetStageId = resStageId;
            StageList[resStageId].IsBuyTarget = 1;
            if (tempStage.type <= 3) {
                ProductPriorityQueue_123.push(tempStage);
            } else {
                ProductPriorityQueue_4567.push(tempStage);
            }
        }
    }   
}


void Project::MoveRobot()
{
    unordered_set<int> IdleRobotSet;
    for (int i = 0; i < 4; ++i) {
        if ((IdleRobot & (1 << i)) && RobotList[i].TargetStageId == -1) { // 空闲
            IdleRobotSet.insert(i);
        } else {
            int robotid = i;
            Robot curRobot = RobotList[robotid];
            if (curRobot.StageId == curRobot.TargetStageId) { // 到达了目的地
                if (curRobot.CarriedItemType != 0) { // 携带了商品
                    if ((StageList[curRobot.StageId].RawGridStatus & (1 << curRobot.CarriedItemType)) == 0) {
                        printf("sell %d\n", robotid);
                        StageList[curRobot.TargetStageId].IsSellTarget[curRobot.CarriedItemType] = 0;
                        balance += ProductValue::ProductList[curRobot.CarriedItemType].sellValue * curRobot.CollisionValueCoef * curRobot .TimeValueCoef;
                        if (!RobotBuyItem(robotid, curRobot.StageId)) {
                            ToIdle(robotid);
                            IdleRobotSet.insert(robotid);
                            RobotList[robotid].TargetStageId = -1;
                            RobotList[robotid].CarriedItemType = 0;
                        }
                    } else {
                        printf("destroy %d\n", robotid);
                        if (!RobotBuyItem(robotid, curRobot.StageId)) {
                            ToIdle(robotid);
                            IdleRobotSet.insert(robotid);
                            RobotList[robotid].TargetStageId = -1;
                            RobotList[robotid].CarriedItemType = 0;
                        }
                    }
                } else if (curRobot.CarriedItemType == 0) {  // 没有携带商品，那就是来买的
                    if (!RobotBuyItem(robotid, curRobot.StageId)) {
                        ToIdle(robotid);
                        IdleRobotSet.insert(robotid);
                        RobotList[robotid].TargetStageId = -1;
                        RobotList[robotid].CarriedItemType = 0;
                    }
                    StageList[curRobot.StageId].IsBuyTarget = 0;
                }
            } else { // 没到目的地
                
                // if (curRobot.CarriedItemType >= 6 && curRobot.CollisionValueCoef * curRobot.TimeValueCoef < 0.60) { // 6,7号商品时间与碰撞乘积小于0.75时几乎没有利润
                //     // 携带了商品
                //     // printf("destroy %d\n", robotid);
                //     // printf("rotate %d %f\n", robotid, 0.0);
                //     // printf("forward %d %f\n", robotid, 0.0);
                //     // ToIdle(robotid);
                //     // IdleRobotSet.insert(robotid);
                //     // StageList[curRobot.TargetStageId].IsSellTarget[curRobot.CarriedItemType] = 0;
                //     // RobotList[robotid].TargetStageId = -1;
                //     // RobotList[robotid].CarriedItemType = 0;
                // }
                if (curRobot.CarriedItemType >= 6) {
                    continue;
                } else if (curRobot.CarriedItemType >= 4 && curRobot.CollisionValueCoef * curRobot.TimeValueCoef < 0.68) {
                    printf("destroy %d\n", robotid);
                    printf("rotate %d %f\n", robotid, 0.0);
                    printf("forward %d %f\n", robotid, 0.0);
                    ToIdle(robotid);
                    IdleRobotSet.insert(robotid);
                    StageList[curRobot.TargetStageId].IsSellTarget[curRobot.CarriedItemType] = 0;
                    RobotList[robotid].TargetStageId = -1;
                    RobotList[robotid].CarriedItemType = 0;
                } else if (curRobot.CarriedItemType >= 1 && curRobot.CollisionValueCoef * curRobot.TimeValueCoef < 0.63) {
                    printf("destroy %d\n", robotid);
                    printf("rotate %d %f\n", robotid, 0.0);
                    printf("forward %d %f\n", robotid, 0.0);
                    ToIdle(robotid);
                    IdleRobotSet.insert(robotid);
                    StageList[curRobot.TargetStageId].IsSellTarget[curRobot.CarriedItemType] = 0;
                    RobotList[robotid].TargetStageId = -1;
                    RobotList[robotid].CarriedItemType = 0;
                } else {
                    AdjustRobotTarget(robotid);
                }
            }
        }
    }

    if (!IdleRobotSet.empty()) {
        for (auto it = IdleRobotSet.begin(); it != IdleRobotSet.end();) {
            int stageid = AssignmentTargetStage(*it);
            if (stageid != -1) {
                RobotList[*it].TargetStageId = stageid;
                StageList[stageid].IsBuyTarget = 1;
                ToBusy(*it);
                it = IdleRobotSet.erase(it);
            } else {
                ++it;
            }
        }
    }

    AdjustDirectionAndSpeed();

}


bool Project::InsertToMProductToStage(int RawGridStatus, int ProductType, int StageId)
{
    if ((RawGridStatus & (1 << ProductType)) == 0 && StageList[StageId].IsSellTarget[ProductType] == 0) {
        m_ProductToStage[ProductType].insert(StageId);
    }
    return true;
}

bool Project::readMapUntilOK()
{
	char line[1024];
	int x = 0;
	while (fgets(line, sizeof(line), stdin)) {
		if (line[0] == 'O' && line[1] == 'K') {
			return true;
		}
		// 导入地图
		for (int i = 0; line[i] != '\0' && line[i] != '\n'; ++i) {
			Map::InsertToMap(x, i, line[i]);
		}
		++x;
	}
	return true;
}

bool Project::readFrameUntilOK()
{
	char line[1024];
	int x = 0;
    int robotId = 0;
    int stageId = 0;
    priority_queue<Stage, vector<Stage>, ProductPriorityQueueCmpFunc> t1;
    priority_queue<Stage, vector<Stage>, ProductPriorityQueueCmpFunc> t2;
    ProductPriorityQueue_123 = t1;
    ProductPriorityQueue_4567 = t2;
    m_ProductToStage.clear();
	while (fgets(line, sizeof(line), stdin)) {
		if (line[0] == 'O' && line[1] == 'K') {
			return true;
		}
		if (x == 0) {
			int i = 1;
			int b = 0;
            int sign = 1;
			while (line[i] != '\0' && line[i] != '\n') {
                if (line[i] == '-') {
                    sign = -1;
                } else {
                    b *= 10;
				    b += line[i] - '0';
                }
                ++i;
			}
			balance = b * sign;

            #ifdef debug
            cout << "Project::readFrameUntilOK():478:balance: " << balance << endl;
            #endif
		} else if (x == 1) {
			int num = 0;
			for (int i = 0; line[i] != '\0' && line[i] != '\n'; ++i) {
                #ifdef debug
                cout << line[i] << "|";
                #endif
				num *= 10;
				num += line[i] - '0';
			}
			StageNum = num;

            #ifdef debug
            cout << "Project::readFrameUntilOK():489:StageNum: " << num << endl;
            #endif
		} else {
			if (stageId < StageNum) { // 读取工作台信息
                vector<int> a(8, 0);
                vector<double> b(4, 0.0);
				int id = 0;
                double sign = 1.0;
				for (int i = 0; line[i] != '\0' && line[i] != '\n'; ++i) {
					if (id != 1 && id != 2) {
						while (line[i] != '\0' && line[i] != ' ' && line[i] != '\n') {
                            if (line[i] == '-') {
                                sign = -1.0;
                            } else {
                                a[id] *= 10;
							    a[id] += line[i] - '0';
                            }
                            ++i;
						}
                        a[id] *= sign;
					} else {
						bool flag = true; // 小数和整数部分
						double deci = 0.1;
						while (line[i] != '\0' && line[i] != ' ' && line[i] != '\n') {
                            if (line[i] == '-') {
                                sign = -1.0;
                            } else if (line[i] == '.') {
								flag = false;
							} else if (flag) {
								b[id] *= 10.0;
								b[id] += line[i] - '0';
							} else {
								b[id] += deci * (line[i] - '0');
								deci /= 10.0;
							}
                            ++i;
						}
                        b[id] *= sign;
					}
					++id;
                    sign = 1.0;
				}
                a[3] = a[3] == -1 ? 3000 : a[3];
				StageList[stageId].UpdateStageStatus(stageId, a[0], DoubleXY(b[1], b[2]), a[3], a[4], a[5]);
                
                #ifdef debug
                cout << "Project::readFrameUntilOK(): 516: " << stageId << " " << a[0] << " " << b[1] << " " << b[2] << " " << a[3] << " " << a[4] << " " << a[5] << endl;
                #endif

                if (a[0] > 3) { // 收购
                    switch (a[0]) {
                        case 4:
                            InsertToMProductToStage(a[4], 1, stageId);
                            InsertToMProductToStage(a[4], 2, stageId);
                            break;
                        case 5:
                            InsertToMProductToStage(a[4], 1, stageId);
                            InsertToMProductToStage(a[4], 3, stageId);
                            break;
                        case 6:
                            InsertToMProductToStage(a[4], 2, stageId);
                            InsertToMProductToStage(a[4], 3, stageId);
                            break;
                        case 7:
                            InsertToMProductToStage(a[4], 4, stageId);
                            InsertToMProductToStage(a[4], 5, stageId);
                            InsertToMProductToStage(a[4], 6, stageId);
                            break;
                        case 8 :
                            InsertToMProductToStage(a[4], 7, stageId);
                            break;
                        case 9:
                            for (int k = 1; k <= 7; ++k) {
                                InsertToMProductToStage(a[4], k, stageId);
                            }
                            break;
                        default:
                            break;
                    }
                }
                if (a[0] < 8 && StageList[stageId].IsBuyTarget == 0) {
                    if (a[0] <= 3) {
                        ProductPriorityQueue_123.push(StageList[stageId]);
                    } else {
                        ProductPriorityQueue_4567.push(StageList[stageId]);
                    }
                    
                }
                ++stageId;
			} else { // 机器人行列
                vector<int> a(3, 0);
                vector<double> b(12, 0.0);
				int id = 0;
                double sign = 1.0;
				for (int i = 0; line[i] != '\0' && line[i] != '\n'; ++i) {
					if (id == 0 || id == 1) {  // 读取整数
						while (line[i] != '\0' && line[i] != ' ' && line[i] != '\n') {
                            if (line[i] == '-') {
                                sign = -1.0;
                            } else {
                                a[id] *= 10;
							    a[id] += line[i] - '0';
                            }
                            ++i;
						}
                        a[id] *= sign;
					} else {
						bool flag = true; // 小数和整数部分
						double deci = 0.1;
						while (line[i] != '\0' && line[i] != ' ' && line[i] != '\n') {
                            if (line[i] == '-') {
                                sign = -1.0;
                            } else if (line[i] == '.') {
								flag = false;
							}
							else if (flag) {
								b[id] *= 10.0;
								b[id] += line[i] - '0';
							}
							else {
								b[id] += deci * (line[i] - '0');
								deci /= 10.0;
							}
                            ++i;
						}
                        b[id] *= sign;
					}
					++id;
                    sign = 1.0;
				}
				RobotList[robotId].UpdateRobotStatus(a[0], a[1], b[2], b[3], b[4], DoubleXY(b[5], b[6]), b[7], DoubleXY(b[8], b[9]));

                #ifdef debug
                cout << "Project::readFrameUntilOK(): 587: " << a[0] << " " << a[1] << " " << b[2] << " " << b[3] << " " << b[4] << " " << b[5] 
                     << " " << b[6] << " " << b[7] << " " << b[8] << " " << b[9] << endl;
                #endif

                ++robotId;
			}
		}
		++x;
	}
	return true;
}


int main()
{
    //sleep(10);
	Project project;
	project.run();
	return 0;
	
}