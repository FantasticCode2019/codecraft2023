#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <sys/time.h>
using namespace std;

#define Pi 3.1415926

constexpr double g_m[2] = {Pi * 0.4 * 0.4 * 20, Pi * 0.53 * 0.53 * 20}; // 空闲时质量， 持物时质量
constexpr double g_va[2] = {250 / (Pi * 0.4 * 0.4 * 20), 250 / (Pi * 0.53 * 0.53 * 20)};  // 空闲与持物时数度加速度
constexpr double g_wa[2] = {50 / (Pi * 0.4 * 0.4 * 0.4 * 0.4 * 20), 50 / (Pi * 0.53 * 0.53 * 0.53 * 0.53 * 20)}; // 空闲与持物时角加速度


struct DoubleXY
{
	double x, y;
	DoubleXY() = default;
	DoubleXY& operator= (const DoubleXY& pos) {
		this->x = pos.x;
		this->y = pos.y;
		return *this;
	}
	DoubleXY(double x, double y) {
		this->x = x;
		this->y = y;
	}
};


struct RobotPose
{
    double x, y;
    double yam;
    double v, w;
    RobotPose() = default;
    RobotPose(double x, double y, double yam, double v, double w) {
        this->x = x;
        this->y = y;
        this->yam = yam;
        this->v = v;
        this->w = w;
    }
    RobotPose& operator= (const RobotPose& state) {
        x = state.x;
        y = state.y;
        yam = state.yam;
        v = state.v;
        w = state.w;
        return *this;
    }
};

class DWA
{
public:
    DWA(double dt, double vMin, double vMax, double wMin, double wMax, double predictTime, double aVmax, double aWmax,
        double vSample, double wSample, double a, double b, double c, double radius, double judgeDistance);

    RobotPose KinematicModel(RobotPose state, const vector<double>& control, double dt);

    pair<vector<double>, vector<RobotPose>> DwaControl(int IsCarrid, RobotPose state, DoubleXY goal, const vector<DoubleXY>& obstacle);
    
    vector<double> CalVelLimit();
    vector<double> CalAccelLimit(double v, double w);
    vector<double> CalObstacleLimit(RobotPose state, const vector<DoubleXY>& obstacle);
    vector<double> CalDynamicWindowVel(double v, double w, RobotPose state, const vector<DoubleXY>& obstacle);
    
    vector<RobotPose> TrajectoryPredict(RobotPose state, double v, double w);
    pair<vector<double>,vector<RobotPose>> TrajectoryEvaluation(RobotPose state, DoubleXY goal, const vector<DoubleXY>& obstacle);
    
    double dist(RobotPose state, const vector<DoubleXY>& obstacle);
    double heading(const vector<RobotPose>& trajectory, DoubleXY goal);
    double velocity(const vector<RobotPose>& trajectory);
    double distance(const vector<RobotPose>& trajectory, const vector<DoubleXY>& obstacle);
    double svelocity(DoubleXY cur, DoubleXY temp);
    double mvelocity(double v);
    double fun(RobotPose state, DoubleXY goal,const vector<RobotPose>& trajectory);
    double GetDistance(DoubleXY p1, DoubleXY p2);

private:
    double dt;
    double v_min,v_max,w_min,w_max;
    double predict_time;//轨迹推算时间长度
    double a_vmax,a_wmax; //线加速度和角加速度最大值
    double v_sample,w_sample; //采样分辨率
    double a, b, c; //轨迹评价函数系数
    double radius; // 用于判断是否到达目标点
    double judge_distance; //若与障碍物的最小距离大于阈值（例如这里设置的阈值为robot_radius+0.2）,则设为一个较大的常值
};

DWA::DWA(double dt, double vMin, double vMax, double wMin, double wMax, double predictTime, double aVmax, double aWmax,
         double vSample, double wSample, double a, double b, double c, double radius, double judgeDistance)
        : dt(dt), v_min(vMin), v_max(vMax), w_min(wMin), w_max(wMax), predict_time(predictTime), a_vmax(aVmax),
          a_wmax(aWmax), v_sample(vSample), w_sample(wSample), a(a), b(b), c(c), radius(radius),
          judge_distance(judgeDistance) {}



double DWA::GetDistance(DoubleXY p1, DoubleXY p2) {
    return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2. y) * (p1.y - p2.y));
}

/**
 * 计算速度边界限制Vm
 * @return 速度边界限制后的速度空间Vm
 */
// vector<double> DWA::calVelLimit() {
//     return {v_min,v_max,w_min,w_max };
// }

/**
 * 计算加速度限制Vd
 * @return
 */
vector<double> DWA::CalAccelLimit(double v, double w) {
    double v_low = v-a_vmax*dt;
    double v_high = v+a_vmax*dt;
    double w_low = w-a_wmax*dt;
    double w_high = w+a_wmax*dt;
    return {v_low, v_high,w_low, w_high};
}

/**
 * 环境障碍物限制Va
 * @param state 当前机器人状态
 * @param obstacle 障碍物位置
 * @return 移动机器人不与周围障碍物发生碰撞的速度空间Va
 */
vector<double> DWA::CalObstacleLimit(RobotPose state, const vector<DoubleXY>& obstacle) {
    double v_low=v_min;
    double v_high = sqrt(2*dist(state,obstacle)*a_vmax);
    double w_low =w_min;
    double w_high = sqrt(2*dist(state,obstacle)*a_wmax);
    return {v_low, v_high,w_low, w_high};
}

/**
 * 速度采样,得到速度空间窗口
 * @param v 当前时刻线速度
 * @param w 当前时刻角速度
 * @param state 当前机器人状态
 * @param obstacle 障碍物位置
 * @return [v_low,v_high,w_low,w_high]: 最终采样后的速度空间
 */
vector<double> DWA::CalDynamicWindowVel(double v, double w, RobotPose state, const vector<DoubleXY>& obstacle) {


    vector<double> Vm{v_min,v_max,w_min,w_max};
    vector<double> Vd = CalAccelLimit(v, w);
    vector<double> Va = CalObstacleLimit(state, obstacle);
    double a = max({Vm[0],Vd[0],Va[0]});
    double b = min({Vm[1],Vd[1],Va[1]});
    double c = max({Vm[2], Vd[2],Va[2]});
    double d = min({Vm[3], Vd[3],Va[3]});
    return {a,b,c,d};
}

/**
 * 计算当前移动机器人距离障碍物最近的几何距离
 * @param state 当前机器人状态
 * @param obstacle 所有障碍物位置
 * @return 移动机器人距离障碍物最近的几何距离
 */
double DWA::dist(RobotPose state, const vector<DoubleXY>& obstacle) {
    double min_dist = 100000;
    for(DoubleXY obs:obstacle){
        double distance = GetDistance(obs, DoubleXY(state.x, state.y));
        min_dist = distance>min_dist?min_dist:distance;
    }
    return min_dist;
}


/**
 * 机器人运动学模型
 * @param state 状态量---x,y,yaw,v,w
 * @param control 控制量---v,w,线速度和角速度
 * @param dt 采样时间
 * @return 下一步的状态
 */
RobotPose DWA::KinematicModel(RobotPose state, const vector<double>& control, double dt) {

    state.x += control[0] * cos(state.yam) * dt;
    state.y += control[0] * sin(state.yam) * dt;
    state.yam += control[1] * dt;
    state.v = control[0];
    state.w = control[1];

    return state;
}

/**
 * 轨迹推算
 * @param state 当前状态---x,y,yaw,v,w
 * @param v 当前时刻线速度
 * @param w 当前时刻线速度
 * @return 推算后的轨迹
 */
vector<RobotPose> DWA::TrajectoryPredict(RobotPose state, double v, double w) {
    vector<RobotPose> trajectory;
    trajectory.push_back(state);
    double time =0;
    while(time<=predict_time){
        state = KinematicModel(state,{v,w},dt);
        if (state.x <= 0.53 || state.y <= 0.53 || state.x >= 49.47 || state.y >= 49.47) {
            break;
        }
        trajectory.push_back(state);
        time+=dt;
    }
    return trajectory;
}

/**
 * 轨迹评价函数,评价越高，轨迹越优
 * @param state 当前状态---x,y,yaw,v,w
 * @param goal 目标点位置，[x,y]
 * @param obstacle 障碍物位置，dim:[num_ob,2]
 * @return 最优控制量、最优轨迹
 */
pair<vector<double>, vector<RobotPose>> DWA::TrajectoryEvaluation(RobotPose state, DoubleXY goal, const vector<DoubleXY>& obstacle) {
    double G_max = -10000000; //最优评价
    vector<RobotPose> trajectory_opt; //最优轨迹
    trajectory_opt.push_back(state);
    vector<double> control_opt={0.,0.}; // 最优控制
    vector<double> SpeedSpace = CalDynamicWindowVel(state.v,state.w,state,obstacle);//第1步--计算速度空间

    // double sum_heading =0.0,sum_dist=0.0,sum_vel=0.0;//统计全部采样轨迹的各个评价之和，便于评价的归一化
    // double v = SpeedSpace[0]; // 最低线速度
    // double w = SpeedSpace[2]; // 最低角速度
    // while(v<SpeedSpace[1]){
    //     while(w<SpeedSpace[3]){
    //         vector<RobotPose>trajectory = TrajectoryPredict(state,v,w);
    //         double heading_eval = a * heading(trajectory,goal);
    //         double dist_eval = b * distance(trajectory,obstacle);
    //         double vel_eval = c * velocity(trajectory);
    //         sum_vel+=vel_eval;
    //         sum_dist+=dist_eval;
    //         sum_heading+=heading_eval;
    //         double G = heading_eval+dist_eval+vel_eval;
    //         if(G_max<=G){
    //             G_max = G;
    //             trajectory_opt=trajectory;
    //             control_opt={v,w};
    //         }
    //         w+=w_sample;
    //     }
    //     v+=v_sample;
    //     w = SpeedSpace[2];
    // }

    double sum_heading =1.0,sum_dist=1.0,sum_vel=1.0;//不进行归一化
    double v = SpeedSpace[0];
    double w = SpeedSpace[2];
    while(v<SpeedSpace[1]){
        while(w<SpeedSpace[3]){
            vector<RobotPose> trajectory = TrajectoryPredict(state,v,w);//第2步--轨迹推算

            double heading_eval = a * heading(trajectory,goal)/sum_heading;
            double dist_eval = b * distance(trajectory,obstacle)/sum_dist;
            double vel_eval = c * velocity(trajectory)/sum_vel;
            double s_eval = 0.5 * fun(state, goal, trajectory) / 1.0;

            double G = heading_eval + dist_eval + vel_eval + s_eval; // 第3步--轨迹评价

            if(G_max<=G){
                G_max = G;
                trajectory_opt=trajectory;
                control_opt={v,w};
            }
            w+=w_sample;
        }
        v+=v_sample;
        w = SpeedSpace[2];
    }
    return {control_opt,trajectory_opt};

}



double DWA::fun(RobotPose state, DoubleXY goal,const vector<RobotPose>& trajectory) {
    // double A = StartPos.x - goal.x, B = goal.y - StartPos.y, C = goal.x * StartPos.y - StartPos.x * goal.y;
    // double t = A * A + B * B;
    // double x0 = trajectory.back().x, y0 = trajectory.back().y;
    // double dis = abs(A * x0 + B * y0 + C) / sqrt(t);
    // if (dis < 1.0) {
    //     return 2.0 - dis;
    // } else {
    //     1.0 / dis;
    // }

    double dis = GetDistance(DoubleXY(trajectory.back().x, trajectory.back().y), goal);
    // if (dis > 30) {
    //     return 30 / dis;
    // } else {
    //     return 69 / dis;
    // }
    return 69 / dis;
    // double A = state.x - goal.x, B = goal.y - state.y, C = goal.x * state.y - state.x * goal.y;
    // double t = A * A + B * B;
    // double x0 = trajectory.back().x, y0 = trajectory.back().y;
    // double dis = abs(A * x0 + B * y0 + C) / sqrt(t);
    // double x = (B * B * x0 - A * B * y0 - A * C) / t;
    // double y = (- A * B * x0 + A * A * y0 - B * C) / t;
    // double x1 = min(state.x, goal.x), x2 = max(state.x, goal.x);
    // double y1 = min(state.y, goal.y), y2 = max(state.y, goal.y);
    // if (dis < 1.5 && x >= x1 && x <= x2 && y >= y1 && y <= y2) {
    //     return 3.0 - dis;
    // } else {
    //     1.5 / dis;
    // }
}


/**
 * 方位角评价函数
 * 评估在当前采样速度下产生的轨迹终点位置方向与目标点连线的夹角的误差
 * @param trajectory 轨迹，dim:[n,5]
 * @param goal 目标点位置[x,y]
 * @return 方位角评价数值
 */
double DWA::heading(const vector<RobotPose>& trajectory, DoubleXY goal) {
    double tx = goal.x - trajectory.back().x, ty = goal.y - trajectory.back().y;
    double error_angle = atan2(ty, tx);
    // double cost_angle = error_angle-trajectory.back().yam;
    // double cost = Pi-abs(cost_angle);
    // return cost;
    if (error_angle < 0) {
        error_angle += 2 * Pi;
    }
    double CurDir = trajectory.back().yam;
    if (CurDir < 0) {
        CurDir += 2 * Pi;
    }
    double gap = CurDir > error_angle ? CurDir - error_angle : error_angle - CurDir;
    if (gap > Pi) {
        gap = 2 * Pi - gap;
    }
    return 2 * Pi - gap;

}

/**
 * 速度评价函数
 * 表示当前的速度大小，可以用模拟轨迹末端位置的线速度的大小来表示
 * @param trajectory 轨迹，dim:[n,5]
 * @return 速度评价值
 */
double DWA::velocity(const vector<RobotPose>& trajectory) {
    return trajectory.back().v;
}

/**
 * 距离评价函数
 * 表示当前速度下对应模拟轨迹与障碍物之间的最近距离；
 * 如果没有障碍物或者最近距离大于设定的阈值，那么就将其值设为一个较大的常数值。
 * @param trajectory 轨迹，dim:[n,5]
 * @param obstacle 障碍物位置，dim:[num_ob,2]
 * @return 距离评价值
 */
double DWA::distance(const vector<RobotPose>& trajectory, const vector<DoubleXY>& obstacle) {
    double min_r = 10000000.0;
    for(const DoubleXY& obs:obstacle){
        for(const RobotPose& state:trajectory){
            double r = GetDistance(obs, DoubleXY(state.x, state.y));
            min_r = min_r>r?r:min_r;
        }
    }
    if (min_r < 1.3) {
        return min_r;
    } else {
        return judge_distance * 1.2;
    }

    // if(min_r<1.5){
    //     return min_r;
    // }else{
    //     return 2.0;
    // }
}


/**
 * 滚动窗口算法控制器
 * @param state 机器人当前状态--[x,y,yaw,v,w]
 * @param goal 目标点位置，[x,y]
 * @param obstacle 障碍物位置，dim:[num_ob,2]
 * @return  最优控制量[v,w]、最优轨迹
 */
pair<vector<double>, vector<RobotPose>> DWA::DwaControl(int IsCarrid, RobotPose state, DoubleXY goal, const vector<DoubleXY>& obstacle) {
    // a_vmax = g_va[IsCarrid];
    // a_wmax = g_wa[IsCarrid];
    // if (IsCarrid) {
    //     v_sample = 0.05;
    //     w_sample = 1.0 * Pi / 180;
    // } else {
    //     v_sample = 0.1;
    //     w_sample = 2.0 * Pi / 180;
    // }
    pair<vector<double>, vector<RobotPose>> res = TrajectoryEvaluation(state,goal,obstacle);
    return res;
}