#!/bin/sh
cd "$( dirname "$0" )"
sudo ./Robot_gui "python3 Demo/keyboard_demo.py" ./Demo/SimpleDemo -m maps/1.txt