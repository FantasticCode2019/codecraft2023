#!/bin/sh
cd "$( dirname "$0" )"
./Robot_gui ./Demo/SimpleDemo ./Demo/SimpleDemo -m maps/5.txt