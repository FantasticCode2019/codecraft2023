#!/bin/sh
cd "$( dirname "$0" )"
./Robot -f ./Demo/SimpleDemo ./Demo/SimpleDemo -m maps/1.txt