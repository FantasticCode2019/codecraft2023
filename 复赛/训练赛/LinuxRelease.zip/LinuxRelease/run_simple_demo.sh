#!/bin/sh
cd "$( dirname "$0" )"
./Robot_gui ./Demo/SimpleDemo -m maps/1.txt